package com.example.ewalletexample.service.realtimeDatabase;

public interface ResponseModelByKey<T> {
    void GetModel(T data);
}
