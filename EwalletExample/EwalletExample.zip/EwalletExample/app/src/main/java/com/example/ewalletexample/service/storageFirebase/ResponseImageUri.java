package com.example.ewalletexample.service.storageFirebase;

import android.net.Uri;

public interface ResponseImageUri {
    void GetImageUri(Uri imageUri);
}
