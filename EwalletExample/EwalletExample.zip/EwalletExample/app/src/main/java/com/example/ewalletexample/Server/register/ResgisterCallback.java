package com.example.ewalletexample.Server.register;

public interface ResgisterCallback {
    void RegisterSuccessful(String userid, String fullName, String phone);
}
