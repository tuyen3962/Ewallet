package com.example.ewalletexample.service.websocket;

public interface WebsocketResponse {
    void UpdateWallet(String userid, long balance);
}
