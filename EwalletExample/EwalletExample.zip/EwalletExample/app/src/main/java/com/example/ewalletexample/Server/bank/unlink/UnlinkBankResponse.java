package com.example.ewalletexample.Server.bank.unlink;

public interface UnlinkBankResponse {
    void UnlinkResponse(boolean response);
}
