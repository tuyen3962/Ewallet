package com.example.ewalletexample.service;

public enum  MobileNetworkOperator {
    MOBIPHONE, VIETTEL, VINAPHONE, VIETNAMMOBILE, GMOBILE, NONE
}
