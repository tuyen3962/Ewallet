package com.example.ewalletexample.Server.VerifyPin;

public interface VerifyResponse {
    void VerifyPinResponse(boolean isSuccess);
}
