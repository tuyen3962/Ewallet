package com.example.ewalletexample.service;

import com.example.ewalletexample.model.UserSearchModel;

public interface UserSelectFunction {
    void SelectUserExchangeMoney(UserSearchModel model);
}
