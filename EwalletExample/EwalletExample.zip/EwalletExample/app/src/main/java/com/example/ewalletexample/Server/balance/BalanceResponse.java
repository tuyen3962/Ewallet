package com.example.ewalletexample.Server.balance;

public interface BalanceResponse {
    void GetBalanceResponse(long balance);
}
