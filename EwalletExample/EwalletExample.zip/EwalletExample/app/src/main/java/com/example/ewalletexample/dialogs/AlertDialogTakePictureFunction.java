package com.example.ewalletexample.dialogs;

public interface AlertDialogTakePictureFunction {
    public void TakePhoto();

    public void ChoosePicture();
}
