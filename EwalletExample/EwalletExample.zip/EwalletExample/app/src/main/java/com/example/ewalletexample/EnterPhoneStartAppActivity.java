package com.example.ewalletexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EnterPhoneStartAppActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_phone_start_app);
    }
}
