package com.example.ewalletexample.service;

public interface ResponseMethod {
    void SetMessageProgressBar(String message);

    void HideProgressBar();

    void GetImageServerFile(String serverFile);
}
