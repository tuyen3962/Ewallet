package com.example.ewalletexample.Server.user.update;

public interface UpdateUserResponse {
    void UpdateSuccess();

    void UpdateFail();
}
