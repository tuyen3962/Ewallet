package com.example.ewalletexample.Server.order;

public interface MobileCardOrderResponse {
    void ResponseMobileCard(String cardNumber, String seriNumber);
}
